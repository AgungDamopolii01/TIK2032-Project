function welcomeMessage() {
  alert("Selamat datang di Website Pribadi saya!");
}

function showTime() {
  const now = new Date();
  alert("Waktu saat ini: " + now.toLocaleString());
}